<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\InteractsWithStock;
use Tests\TestCase;

/**
 * Otorisasi ditegakkan di server (middleware/Gate), bukan hanya disembunyikan di UI.
 */
class RoleAccessTest extends TestCase
{
    use InteractsWithStock, RefreshDatabase;

    public function test_guest_is_redirected_to_login_for_protected_pages(): void
    {
        foreach (['/dashboard', '/barang', '/penjualan', '/pembelian', '/katalog', '/pesanan-saya', '/pengguna'] as $url) {
            $this->get($url)->assertRedirect('/login');
        }
    }

    public function test_admin_can_open_all_admin_pages(): void
    {
        $admin = $this->admin();

        foreach (['/dashboard', '/kategori', '/supplier', '/barang', '/barang/create', '/pengguna', '/gudang', '/penjualan', '/penjualan/create',
            '/pembelian', '/pembelian/create', '/stok-keluar', '/transfer-stok', '/transaksi', '/stok-menipis', '/prediksi-stok',
            '/laporan/penjualan', '/laporan/laba-rugi', '/laporan/neraca-saldo', '/laporan/buku-besar', '/laporan/jurnal',
            '/pengeluaran', '/mata-uang', '/integrasi'] as $url) {
            $this->actingAs($admin)->get($url)->assertOk();
        }
    }

    public function test_staff_can_open_operational_pages(): void
    {
        $staff = $this->staff();

        foreach (['/dashboard', '/barang', '/stok-menipis', '/penjualan', '/penjualan/create', '/pembelian', '/pembelian/create',
            '/stok-keluar', '/transfer-stok', '/transaksi', '/prediksi-stok'] as $url) {
            $this->actingAs($staff)->get($url)->assertOk();
        }
    }

    public function test_staff_cannot_access_admin_functions_via_direct_url(): void
    {
        $staff = $this->staff();
        $barang = $this->product();

        foreach (['/kategori', '/supplier', '/pengguna', '/pengguna/create', '/gudang', '/barang/create', "/barang/{$barang->id}/edit",
            '/laporan/laba-rugi', '/laporan/jurnal', '/pengeluaran', '/mata-uang', '/integrasi'] as $url) {
            $this->actingAs($staff)->get($url)->assertForbidden();
        }

        $this->actingAs($staff)->post('/barang', ['name' => 'X'])->assertForbidden();
        $this->actingAs($staff)->delete("/barang/{$barang->id}")->assertForbidden();
        $this->actingAs($staff)->post('/pengguna', ['name' => 'X'])->assertForbidden();
    }

    public function test_customer_cannot_access_internal_pages(): void
    {
        $customer = $this->customer();

        foreach (['/barang', '/penjualan', '/penjualan/create', '/pembelian', '/stok-keluar', '/transaksi', '/kategori', '/pengguna', '/laporan/penjualan', '/integrasi'] as $url) {
            $this->actingAs($customer)->get($url)->assertForbidden();
        }
    }

    public function test_customer_can_open_shop_pages_but_staff_cannot(): void
    {
        $this->actingAs($this->customer());
        foreach (['/dashboard', '/katalog', '/keranjang', '/pesanan-saya'] as $url) {
            $this->get($url)->assertOk();
        }

        $this->actingAs($this->staff())->get('/katalog')->assertForbidden();
        $this->actingAs($this->admin())->get('/keranjang')->assertForbidden();
    }

    public function test_public_registration_always_creates_customer_even_if_role_is_posted(): void
    {
        $this->post('/register', [
            'name' => 'Calon Admin',
            'email' => 'calon@example.test',
            'password' => 'password-kuat-123',
            'password_confirmation' => 'password-kuat-123',
            'role' => 'admin',
        ])->assertRedirect('/dashboard');

        $this->assertSame('pelanggan', User::where('email', 'calon@example.test')->value('role'));
    }

    public function test_user_cannot_change_own_role_through_profile_update(): void
    {
        $customer = $this->customer();

        $this->actingAs($customer)->patch('/profile', [
            'name' => 'Nama Baru',
            'email' => $customer->email,
            'role' => 'admin',
        ]);

        $this->assertSame('pelanggan', $customer->fresh()->role);
        $this->assertSame('Nama Baru', $customer->fresh()->name);
    }

    public function test_admin_can_manage_users_and_roles(): void
    {
        $admin = $this->admin();

        $this->actingAs($admin)->post('/pengguna', [
            'name' => 'Staff Baru', 'email' => 'baru@example.test', 'role' => 'staff',
            'password' => 'password-kuat-123', 'password_confirmation' => 'password-kuat-123',
        ])->assertRedirect(route('pengguna.index'));

        $user = User::where('email', 'baru@example.test')->first();
        $this->assertSame('staff', $user->role);

        $this->actingAs($admin)->put("/pengguna/{$user->id}", [
            'name' => 'Staff Baru', 'email' => 'baru@example.test', 'role' => 'pelanggan',
        ])->assertRedirect(route('pengguna.index'));
        $this->assertSame('pelanggan', $user->fresh()->role);
    }

    public function test_admin_cannot_demote_or_delete_self_or_last_admin(): void
    {
        $admin = $this->admin();

        $this->actingAs($admin)->put("/pengguna/{$admin->id}", ['name' => $admin->name, 'email' => $admin->email, 'role' => 'staff'])
            ->assertSessionHas('error');
        $this->assertSame('admin', $admin->fresh()->role);

        $this->actingAs($admin)->delete("/pengguna/{$admin->id}")->assertSessionHas('error');
        $this->assertModelExists($admin);
    }

    public function test_user_with_transactions_cannot_be_deleted(): void
    {
        $admin = $this->admin();
        $customer = $this->customer();
        $barang = $this->product(10);

        $this->actingAs($customer)->post("/keranjang/{$barang->id}");
        $this->actingAs($customer)->post('/keranjang/checkout', ['shipping_address' => 'Jl. Contoh No. 1, Lhokseumawe']);

        $this->actingAs($admin)->delete("/pengguna/{$customer->id}")->assertSessionHas('error');
        $this->assertModelExists($customer);
    }
}
