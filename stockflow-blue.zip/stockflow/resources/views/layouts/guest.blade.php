<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="theme-color" content="#1769E0">
    <title>{{ config('app.name', 'StockFlow') }}</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=inter:400,500,600,700" rel="stylesheet" />
    <script>try { var t = localStorage.getItem('sf-theme'); if (t === 'dark' || (!t && window.matchMedia('(prefers-color-scheme: dark)').matches)) document.documentElement.classList.add('dark'); } catch (e) {}</script>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans antialiased">
    <div class="min-h-screen grid lg:grid-cols-2">
        <section class="hidden lg:flex flex-col justify-between p-12 text-white" style="background: radial-gradient(1200px 600px at 20% 0%, #3987F7 0%, #1769E0 35%, #12315A 100%)">
            <div class="flex items-center gap-3 text-2xl font-bold tracking-tight">
                <span class="sf-brand-mark" style="width:42px;height:42px"><x-icon name="box" :size="24" /></span> StockFlow
            </div>
            <div>
                <h2 class="text-4xl font-bold leading-tight tracking-tight">Kelola stok, gudang,<br>pembelian & penjualan<br>dalam satu tempat.</h2>
                <p class="mt-4 text-lg" style="color:#CFE0F8">Peringatan stok otomatis, rekomendasi restock, dan laporan yang selalu sesuai data.</p>
            </div>
            <p class="text-sm" style="color:#9DB7DD">Data demo hanya untuk pembelajaran.</p>
        </section>

        <section class="flex items-center justify-center p-6 sm:p-10">
            <div class="w-full max-w-md sf-page">
                <a href="/" class="lg:hidden flex items-center gap-2 mb-6 text-xl font-bold" style="color:var(--sf-navy)">
                    <span class="sf-brand-mark text-white"><x-icon name="box" :size="20" /></span> StockFlow
                </a>
                <div class="sf-card p-6 sm:p-8">
                    {{ $slot }}
                </div>
            </div>
        </section>
    </div>
</body>
</html>
