<?php

namespace Database\Seeders;

use App\Models\Barang;
use App\Models\Category;
use App\Models\Expense;
use App\Models\JournalEntry;
use App\Models\Purchase;
use App\Models\Sale;
use App\Models\Supplier;
use App\Models\User;
use App\Models\Warehouse;
use App\Services\JournalService;
use App\Services\PurchaseService;
use App\Services\SaleService;
use App\Services\StockTransferService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

/**
 * Data demo realistis (tanpa data pribadi/kredensial asli).
 * Seluruh stok dan transaksi dibuat lewat service yang sama dengan aplikasi,
 * sehingga stok, jurnal, dan laporan konsisten.
 *
 * Akun demo (password: "password"):
 *   admin@inventory.test, staff@inventory.test, pelanggan@inventory.test
 */
class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $journal = app(JournalService::class);
        $journal->ensureAccounts();

        // ---- Pengguna (3 role) ----
        $admin = $this->user('Administrator', 'admin@inventory.test', User::ROLE_ADMIN);
        $staff = $this->user('Staff Gudang', 'staff@inventory.test', User::ROLE_STAFF);
        $this->user('Staff Kasir', 'kasir@inventory.test', User::ROLE_STAFF);
        $budi = $this->user('Budi Santoso', 'pelanggan@inventory.test', User::ROLE_PELANGGAN, '081234567801', 'Jl. Merdeka No. 10, Lhokseumawe');
        $siti = $this->user('Siti Aminah', 'siti@inventory.test', User::ROLE_PELANGGAN, '081234567802', 'Jl. Sudirman No. 5, Aceh Utara');
        $this->user('Rahmat Hidayat', 'rahmat@inventory.test', User::ROLE_PELANGGAN, '081234567803', 'Jl. Pase No. 22, Lhokseumawe');

        // ---- Gudang ----
        $main = Warehouse::default();
        $branch = Warehouse::firstOrCreate(['code' => 'GDG-002'], ['name' => 'Gudang Cabang Banda Aceh', 'address' => 'Jl. T. Nyak Arief No. 3, Banda Aceh']);

        // ---- Kategori & supplier ----
        $categories = collect(['Minuman', 'Makanan Ringan', 'Kebutuhan Rumah', 'Alat Tulis', 'Perawatan Pribadi'])
            ->mapWithKeys(fn ($name) => [$name => Category::firstOrCreate(['name' => $name], ['description' => "Kategori {$name}"])]);

        $suppliers = collect([
            ['PT Sumber Makmur', '0645-123456', 'sales@sumbermakmur.test', 'Jl. Medan-Banda Aceh Km 5, Lhokseumawe'],
            ['CV Aneka Jaya', '0645-654321', 'order@anekajaya.test', 'Jl. Perdagangan No. 8, Lhokseumawe'],
            ['UD Barokah', '0812-0000-1111', 'barokah@supplier.test', 'Pasar Baru Blok C-12, Aceh Utara'],
            ['PT Nusantara Distribusi', '021-555-7788', 'cs@nusantara.test', 'Kawasan Industri Pulogadung, Jakarta'],
        ])->mapWithKeys(fn ($s) => [$s[0] => Supplier::firstOrCreate(['name' => $s[0]], ['phone' => $s[1], 'email' => $s[2], 'address' => $s[3]])]);

        foreach (['PT Sumber Makmur' => 3, 'CV Aneka Jaya' => 5, 'UD Barokah' => 2, 'PT Nusantara Distribusi' => 7] as $name => $days) {
            $suppliers[$name]->update(['lead_time_days' => $days]);
        }

        // Subkategori contoh: Minuman > Susu & Olahan
        $categories['Susu & Olahan'] = Category::firstOrCreate(['name' => 'Susu & Olahan'], ['parent_id' => $categories['Minuman']->id, 'description' => 'Subkategori susu']);

        // ---- Produk (stok awal 0; stok masuk lewat pembelian) ----
        $catalog = [
            ['Air Mineral 600ml', 'Minuman', 'PT Sumber Makmur', 'dus', 38000, 48000, 20, 'Air mineral kemasan 600ml isi 24 botol'],
            ['Teh Botol 450ml', 'Minuman', 'PT Sumber Makmur', 'dus', 62000, 78000, 15, 'Teh manis kemasan botol isi 12'],
            ['Kopi Instan Sachet', 'Minuman', 'CV Aneka Jaya', 'renceng', 12000, 16500, 25, 'Kopi instan 1 renceng isi 10 sachet'],
            ['Susu UHT Cokelat 200ml', 'Minuman', 'PT Nusantara Distribusi', 'dus', 85000, 105000, 10, 'Susu UHT rasa cokelat isi 24'],
            ['Keripik Singkong Balado', 'Makanan Ringan', 'UD Barokah', 'pack', 7500, 11000, 30, 'Keripik singkong pedas 150gr'],
            ['Biskuit Kelapa', 'Makanan Ringan', 'CV Aneka Jaya', 'pack', 9000, 13000, 20, 'Biskuit kelapa 200gr'],
            ['Mie Instan Goreng', 'Makanan Ringan', 'PT Nusantara Distribusi', 'dus', 98000, 118000, 12, 'Mie instan goreng isi 40 bungkus'],
            ['Deterjen Bubuk 800gr', 'Kebutuhan Rumah', 'PT Nusantara Distribusi', 'pcs', 17500, 23000, 15, 'Deterjen bubuk aroma lemon'],
            ['Sabun Cuci Piring 750ml', 'Kebutuhan Rumah', 'CV Aneka Jaya', 'pcs', 12500, 17000, 15, 'Sabun cuci piring jeruk nipis'],
            ['Tisu Wajah 250 Lembar', 'Kebutuhan Rumah', 'UD Barokah', 'pack', 8500, 12500, 20, 'Tisu wajah 2 ply'],
            ['Buku Tulis 38 Lembar', 'Alat Tulis', 'UD Barokah', 'lusin', 28000, 38000, 10, 'Buku tulis sampul kartun isi 12'],
            ['Pulpen Gel Hitam', 'Alat Tulis', 'CV Aneka Jaya', 'lusin', 24000, 33000, 10, 'Pulpen gel 0.5mm isi 12'],
            ['Sampo Anti Ketombe 170ml', 'Perawatan Pribadi', 'PT Nusantara Distribusi', 'pcs', 19000, 26500, 12, 'Sampo anti ketombe'],
            ['Sabun Mandi Batang', 'Perawatan Pribadi', 'PT Sumber Makmur', 'pcs', 3500, 5500, 40, 'Sabun mandi batang 80gr'],
            ['Pasta Gigi 120gr', 'Perawatan Pribadi', 'PT Sumber Makmur', 'pcs', 9500, 14000, 20, 'Pasta gigi mint'],
        ];

        // Produk yang memakai tanggal kedaluwarsa (batch + FEFO). Produk lain tidak memerlukannya.
        $perishable = ['Susu UHT Cokelat 200ml', 'Biskuit Kelapa', 'Keripik Singkong Balado'];

        $products = [];
        foreach ($catalog as $i => [$name, $cat, $sup, $unit, $buy, $sell, $min, $desc]) {
            $products[$name] = Barang::firstOrCreate(['name' => $name], [
                'category_id' => ($name === 'Susu UHT Cokelat 200ml' ? $categories['Susu & Olahan'] : $categories[$cat])->id,
                'supplier_id' => $suppliers[$sup]->id,
                'barcode' => '899'.str_pad((string) (100001 + $i), 10, '0', STR_PAD_LEFT),
                'unit' => $unit, 'purchase_price' => $buy, 'selling_price' => $sell,
                'stock' => 0, 'minimum_stock' => $min, 'description' => $desc, 'is_active' => true,
                'tracks_expiry' => in_array($name, $perishable, true), 'expiry_warning_days' => 30,
            ]);
        }

        if (Purchase::exists()) {
            return; // seeder idempoten: transaksi demo hanya dibuat sekali
        }

        $journal->postOpeningCapital(500_000_000, $admin);

        $purchases = app(PurchaseService::class);
        $sales = app(SaleService::class);

        // ---- Pembelian multi-item (tersebar beberapa bulan agar grafik terisi) ----
        $this->purchase($purchases, $staff, $suppliers['PT Sumber Makmur'], $main, 75, [
            ['Air Mineral 600ml', 40], ['Teh Botol 450ml', 30], ['Sabun Mandi Batang', 100], ['Pasta Gigi 120gr', 40],
        ], $products);
        $this->purchase($purchases, $staff, $suppliers['CV Aneka Jaya'], $main, 60, [
            ['Kopi Instan Sachet', 60], ['Biskuit Kelapa', 40, 150, 'BSK-01'], ['Sabun Cuci Piring 750ml', 30], ['Pulpen Gel Hitam', 20],
        ], $products);
        $this->purchase($purchases, $staff, $suppliers['PT Nusantara Distribusi'], $main, 45, [
            ['Susu UHT Cokelat 200ml', 12, 20, 'UHT-A'], ['Susu UHT Cokelat 200ml', 8, 240, 'UHT-B'], ['Mie Instan Goreng', 25], ['Deterjen Bubuk 800gr', 30], ['Sampo Anti Ketombe 170ml', 24],
        ], $products);
        $this->purchase($purchases, $admin, $suppliers['UD Barokah'], $main, 30, [
            ['Keripik Singkong Balado', 60, 90, 'KRP-01'], ['Tisu Wajah 250 Lembar', 40], ['Buku Tulis 38 Lembar', 20],
        ], $products);
        $this->purchase($purchases, $staff, $suppliers['PT Sumber Makmur'], $main, 10, [
            ['Air Mineral 600ml', 20], ['Teh Botol 450ml', 10],
        ], $products);

        // ---- Transfer ke gudang cabang ----
        app(StockTransferService::class)->transfer($staff, [
            'from_warehouse_id' => $main->id, 'to_warehouse_id' => $branch->id,
            'barang_id' => $products['Air Mineral 600ml']->id, 'quantity' => 15, 'note' => 'Stok awal cabang',
        ]);

        // ---- Penjualan kasir (POS), tersebar beberapa bulan ----
        $kasir = User::where('email', 'kasir@inventory.test')->first();
        $this->sale($sales, $kasir, $main, 70, null, [['Air Mineral 600ml', 6], ['Kopi Instan Sachet', 10]], true, $products);
        $this->sale($sales, $kasir, $main, 55, $budi, [['Mie Instan Goreng', 5], ['Susu UHT Cokelat 200ml', 4]], true, $products);
        $this->sale($sales, $staff, $main, 40, null, [['Teh Botol 450ml', 8], ['Biskuit Kelapa', 12]], true, $products);
        $this->sale($sales, $kasir, $main, 28, $siti, [['Deterjen Bubuk 800gr', 6], ['Sabun Cuci Piring 750ml', 6], ['Tisu Wajah 250 Lembar', 10]], true, $products, ['percent', 10]);
        $this->sale($sales, $kasir, $main, 15, null, [['Buku Tulis 38 Lembar', 4], ['Pulpen Gel Hitam', 14]], false, $products); // belum lunas -> piutang
        $this->sale($sales, $kasir, $main, 6, $budi, [['Air Mineral 600ml', 10], ['Teh Botol 450ml', 6], ['Sabun Mandi Batang', 20]], true, $products);
        $this->sale($sales, $staff, $main, 2, null, [['Keripik Singkong Balado', 25], ['Pasta Gigi 120gr', 15]], true, $products);

        // ---- Penjualan dibatalkan (contoh pembatalan oleh admin; stok kembali) ----
        $cancelled = $this->sale($sales, $kasir, $main, 4, null, [['Sampo Anti Ketombe 170ml', 3]], true, $products);
        $sales->cancel($cancelled, $admin, 'Salah input pelanggan');

        // ---- Pesanan online pelanggan ----
        $pending = $sales->createOrder($budi, [
            'shipping_address' => 'Jl. Merdeka No. 10, Lhokseumawe',
            'note' => 'Tolong dikirim sore hari',
            'items' => [
                ['barang_id' => $products['Kopi Instan Sachet']->id, 'quantity' => 5],
                ['barang_id' => $products['Biskuit Kelapa']->id, 'quantity' => 3],
            ],
        ]);
        app(\App\Services\PaymentService::class)->pay($pending, 'qris');

        $sales->createOrder($siti, [
            'shipping_address' => 'Jl. Sudirman No. 5, Aceh Utara',
            'items' => [['barang_id' => $products['Mie Instan Goreng']->id, 'quantity' => 2]],
        ]);

        $done = $sales->createOrder($budi, [
            'shipping_address' => 'Jl. Merdeka No. 10, Lhokseumawe',
            'items' => [['barang_id' => $products['Deterjen Bubuk 800gr']->id, 'quantity' => 2]],
        ]);
        app(\App\Services\PaymentService::class)->pay($done, 'transfer_bank');
        $sales->complete($done, $staff);

        // ---- Retur penjualan (admin; di luar jendela retur staff) ----
        $returned = Sale::where('customer_id', $budi->id)->where('channel', 'pos')->orderBy('id')->first();
        if ($returned) {
            $line = $returned->items()->where('barang_id', $products['Mie Instan Goreng']->id)->first();
            $sales->returnItems($returned, $admin, ['reason' => 'Kemasan penyok saat diterima', 'items' => [['sale_item_id' => $line->id, 'quantity' => 1]]]);
        }

        // ---- Alur PO: diajukan (menunggu persetujuan), disetujui + diterima sebagian ----
        $po1 = $purchases->createDraft($staff, [
            'supplier_id' => $suppliers['CV Aneka Jaya']->id, 'warehouse_id' => $main->id, 'note' => 'Restok kopi & pulpen',
            'items' => [
                ['barang_id' => $products['Kopi Instan Sachet']->id, 'quantity' => 40, 'unit_cost' => $products['Kopi Instan Sachet']->purchase_price],
                ['barang_id' => $products['Pulpen Gel Hitam']->id, 'quantity' => 20, 'unit_cost' => $products['Pulpen Gel Hitam']->purchase_price],
            ],
        ]);
        $purchases->submit($po1, $staff);

        $po2 = $purchases->createDraft($staff, [
            'supplier_id' => $suppliers['UD Barokah']->id, 'warehouse_id' => $main->id, 'note' => 'Pesanan tisu & buku',
            'items' => [
                ['barang_id' => $products['Tisu Wajah 250 Lembar']->id, 'quantity' => 30, 'unit_cost' => $products['Tisu Wajah 250 Lembar']->purchase_price],
                ['barang_id' => $products['Buku Tulis 38 Lembar']->id, 'quantity' => 10, 'unit_cost' => $products['Buku Tulis 38 Lembar']->purchase_price],
            ],
        ]);
        $purchases->submit($po2, $staff);
        $purchases->approve($po2, $admin);
        $tisuLine = $po2->items()->where('barang_id', $products['Tisu Wajah 250 Lembar']->id)->first();
        $purchases->receive($po2->fresh(), $staff, [['purchase_item_id' => $tisuLine->id, 'quantity' => 20]], 'Pengiriman tahap 1');

        // ---- Transfer yang perlu persetujuan (jumlah >= ambang untuk staff) ----
        config(['stockflow.transfer_approval_threshold' => 20]);
        app(StockTransferService::class)->request($staff, [
            'from_warehouse_id' => $main->id, 'to_warehouse_id' => $branch->id,
            'barang_id' => $products['Sabun Mandi Batang']->id, 'quantity' => 25, 'note' => 'Stok sabun cabang',
        ]);
        config(['stockflow.transfer_approval_threshold' => 100]);

        // ---- Stock opname: satu disetujui, satu menunggu persetujuan ----
        $opnames = app(\App\Services\StockOpnameService::class);
        $o1 = $opnames->create($staff, $main->id, [$products['Pasta Gigi 120gr']->id], 'Opname rutin bulanan');
        $opnames->saveCounts($o1, [$products['Pasta Gigi 120gr']->id => ['counted' => $products['Pasta Gigi 120gr']->fresh()->stock - 1, 'reason' => 'Satu pcs rusak di rak']]);
        $opnames->submit($o1, $staff);
        $opnames->approve($o1, $admin, 'Sesuai hasil pengecekan');

        $o2 = $opnames->create($staff, $branch->id, [$products['Air Mineral 600ml']->id], 'Opname gudang cabang');
        $opnames->saveCounts($o2, [$products['Air Mineral 600ml']->id => ['counted' => 14, 'reason' => 'Selisih 1 dus, dicurigai salah hitung saat transfer']]);
        $opnames->submit($o2, $staff);

        // ---- Beban operasional ----
        foreach ([[40, 'Sewa toko', 3_500_000], [25, 'Listrik & air', 850_000], [12, 'Gaji karyawan', 4_000_000]] as [$ago, $title, $amount]) {
            $expense = Expense::create(['user_id' => $admin->id, 'expense_date' => now()->subDays($ago)->toDateString(), 'title' => $title, 'amount' => $amount]);
            $journal->postExpense($expense);
        }

        // Notifikasi kedaluwarsa & pindai anomali awal (juga berjalan otomatis berkala).
        app(\App\Services\MaintenanceService::class)->run();
    }

    private function user(string $name, string $email, string $role, ?string $phone = null, ?string $address = null): User
    {
        $user = User::firstOrNew(['email' => $email]);
        $user->forceFill([
            'name' => $name, 'role' => $role, 'phone' => $phone, 'address' => $address,
            'password' => Hash::make('password'), 'email_verified_at' => now(),
        ])->save();

        return $user;
    }

    private function purchase(PurchaseService $service, User $user, Supplier $supplier, Warehouse $wh, int $daysAgo, array $lines, array $products): void
    {
        $purchase = $service->create($user, [
            'supplier_id' => $supplier->id,
            'warehouse_id' => $wh->id,
            'note' => 'Pembelian rutin',
            'items' => collect($lines)->map(fn ($l) => [
                'barang_id' => $products[$l[0]]->id, 'quantity' => $l[1], 'unit_cost' => $products[$l[0]]->purchase_price,
                'expiry_date' => isset($l[2]) ? now()->addDays($l[2])->toDateString() : null,
                'batch_number' => $l[3] ?? null,
            ])->all(),
        ]);

        $this->backdate($purchase, 'purchased_at', $daysAgo);
    }

    private function sale(SaleService $service, User $user, Warehouse $wh, int $daysAgo, ?User $customer, array $lines, bool $paid, array $products, ?array $discount = null): Sale
    {
        $sale = $service->createPos($user, [
            'discount_type' => $discount[0] ?? null, 'discount_value' => $discount[1] ?? null,
            'customer_id' => $customer?->id,
            'warehouse_id' => $wh->id,
            'payment_method' => $paid ? 'cash' : null,
            'mark_paid' => $paid,
            'items' => collect($lines)->map(fn ($l) => ['barang_id' => $products[$l[0]]->id, 'quantity' => $l[1]])->all(),
        ]);

        $this->backdate($sale, 'sold_at', $daysAgo);

        return $sale->fresh();
    }

    /** Geser tanggal transaksi demo ke masa lalu (termasuk jurnalnya). */
    private function backdate($model, string $dateColumn, int $daysAgo): void
    {
        $date = now()->subDays($daysAgo);
        $changes = [$dateColumn => $date, 'created_at' => $date];

        if ($model instanceof Sale) {
            $changes['completed_at'] = $date;
            $changes['paid_at'] = $model->paid_at ? $date : null;
        }

        DB::table($model->getTable())->where('id', $model->id)->update(
            collect($changes)->map(fn ($v) => $v?->toDateTimeString())->all()
        );

        DB::table('stock_movements')->where('reference_type', $model->getMorphClass())->where('reference_id', $model->id)
            ->update(['occurred_at' => $date->toDateTimeString(), 'created_at' => $date->toDateTimeString()]);

        if ($model instanceof Purchase) {
            DB::table('purchase_receipts')->where('purchase_id', $model->id)
                ->update(['received_at' => $date->toDateTimeString(), 'created_at' => $date->toDateTimeString()]);
            DB::table('purchases')->where('id', $model->id)->update(['approved_at' => $date->toDateTimeString()]);
        }

        JournalEntry::where('reference_type', $model->getMorphClass())
            ->where('reference_id', $model->id)
            ->update(['entry_date' => $date->toDateString()]);
    }
}
